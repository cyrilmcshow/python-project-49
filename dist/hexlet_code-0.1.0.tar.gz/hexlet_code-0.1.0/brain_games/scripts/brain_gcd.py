#!/usr/bin/env python3

from brain_games.games.brain_gcd_engine import brain_gcd_game


def main():
    brain_gcd_game()


if __name__ == '__main__':
    main()
