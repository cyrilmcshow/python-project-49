### Hexlet tests and linter status:
[![Actions Status](https://github.com/cyrilmcshow/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/cyrilmcshow/python-project-49/actions)

### Code climate tests:
[![Maintainability](https://api.codeclimate.com/v1/badges/b850f1968c0b2d2bb4ca/maintainability)](https://codeclimate.com/github/cyrilmcshow/python-project-49/maintainability)

## Example brain-even:
https://asciinema.org/a/4Cfyg1cvM4SMV7VlIaJc9l8sF

## Example brain-calc:
https://asciinema.org/a/sHtbHfnect8X1Va8cadVb7KwM

## Example brain-gcd:
https://asciinema.org/a/3PmKxht17XzaHeEwkgfaoGU5b

## Example brain-progression:
https://asciinema.org/a/Nc7RLmkGl8pgqakTXTEuqXVzP

## Example brain-prime:
https://asciinema.org/a/JU2xHEqzeazEZKaNqWEJFJKQG
