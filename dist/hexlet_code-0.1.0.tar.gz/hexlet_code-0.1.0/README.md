### Hexlet tests and linter status:
[![Actions Status](https://github.com/cyrilmcshow/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/cyrilmcshow/python-project-49/actions)

## Example brain-even
https://asciinema.org/a/4Cfyg1cvM4SMV7VlIaJc9l8sF

## Example brain-calc
https://asciinema.org/a/sHtbHfnect8X1Va8cadVb7KwM

## Example brain-gcd
https://asciinema.org/a/3PmKxht17XzaHeEwkgfaoGU5b
